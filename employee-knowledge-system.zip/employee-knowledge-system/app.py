from flask import Flask, render_template, request, redirect
import sqlite3
from openai import OpenAI
from dotenv import load_dotenv
import os

# --------------------------------
# APP SETUP
# --------------------------------

load_dotenv()

app = Flask(__name__)

client = OpenAI(
    api_key=os.getenv("GROQ_API_KEY"),
    base_url="https://api.groq.com/openai/v1"
)

# --------------------------------
# DATABASE
# --------------------------------

def create_tables():

    conn = sqlite3.connect("database/knowledge.db")
    cursor = conn.cursor()

    # Knowledge table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS knowledge (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_name TEXT,
        department TEXT,
        problem TEXT,
        solution TEXT,
        lesson TEXT
    )
    """)

    # Question history table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS question_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT
    )
    """)

    conn.commit()
    conn.close()


create_tables()

# --------------------------------
# WELCOME PAGE
# --------------------------------

@app.route("/")
def welcome():
    return render_template("welcome.html")


# --------------------------------
# DASHBOARD
# --------------------------------

@app.route("/dashboard")
def dashboard():

    conn = sqlite3.connect("database/knowledge.db")
    cursor = conn.cursor()

    # Total knowledge entries
    cursor.execute("SELECT COUNT(*) FROM knowledge")
    total_knowledge = cursor.fetchone()[0]

    # Unique employees
    cursor.execute("""
    SELECT COUNT(DISTINCT employee_name)
    FROM knowledge
    """)
    total_employees = cursor.fetchone()[0]

    # AI query count
    cursor.execute("""
    SELECT COUNT(*)
    FROM question_history
    """)
    total_queries = cursor.fetchone()[0]

    # Recent knowledge
    cursor.execute("""
    SELECT employee_name,
           department,
           problem
    FROM knowledge
    ORDER BY id DESC
    LIMIT 5
    """)
    recent_knowledge = cursor.fetchall()

    # Popular questions
    cursor.execute("""
    SELECT question
    FROM question_history
    ORDER BY id DESC
    LIMIT 5
    """)
    questions = cursor.fetchall()

    conn.close()

    return render_template(
        "index.html",
        total_knowledge=total_knowledge,
        total_employees=total_employees,
        total_queries=total_queries,
        accuracy=95,
        recent_knowledge=recent_knowledge,
        questions=questions
    )


# --------------------------------
# SAVE KNOWLEDGE
# --------------------------------

@app.route("/submit", methods=["POST"])
def submit():

    employee_name = request.form["employee_name"]
    department = request.form["department"]
    problem = request.form["problem"]
    solution = request.form["solution"]
    lesson = request.form["lesson"]

    conn = sqlite3.connect("database/knowledge.db")
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO knowledge
    (employee_name,
    department,
    problem,
    solution,
    lesson)

    VALUES (?, ?, ?, ?, ?)
    """, (
        employee_name,
        department,
        problem,
        solution,
        lesson
    ))

    conn.commit()
    conn.close()

    return redirect("/dashboard")


# --------------------------------
# ASK AI
# --------------------------------

@app.route("/ask", methods=["GET", "POST"])
def ask():

    answer = ""

    if request.method == "POST":

        question = request.form["question"]

        conn = sqlite3.connect(
            "database/knowledge.db"
        )
        cursor = conn.cursor()

        # Save question
        cursor.execute("""
        INSERT INTO question_history
        (question)
        VALUES (?)
        """, (question,))

        # Fetch employee knowledge
        cursor.execute("""
        SELECT problem,
               solution,
               lesson
        FROM knowledge
        """)

        rows = cursor.fetchall()

        conn.commit()
        conn.close()

        knowledge_text = ""

        for row in rows:

            knowledge_text += f"""
            Problem: {row[0]}
            Solution: {row[1]}
            Lesson: {row[2]}
            """

        prompt = f"""
        You are an employee
        knowledge assistant.

        Use employee knowledge
        below to answer.

        {knowledge_text}

        User Question:
        {question}

        Give a practical answer.
        """

        response = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )

        answer = (
            response
            .choices[0]
            .message
            .content
        )

    return render_template(
        "ask.html",
        answer=answer
    )


# --------------------------------
# VIEW KNOWLEDGE
# --------------------------------

@app.route("/view")
def view():

    conn = sqlite3.connect(
        "database/knowledge.db"
    )

    cursor = conn.cursor()

    cursor.execute("""
    SELECT *
    FROM knowledge
    ORDER BY id DESC
    """)

    data = cursor.fetchall()

    conn.close()

    return render_template(
        "view.html",
        data=data
    )

@app.route("/delete/<int:id>")
def delete_knowledge(id):

    conn = sqlite3.connect(
        "database/knowledge.db"
    )

    cursor = conn.cursor()

    cursor.execute("""
    DELETE FROM knowledge
    WHERE id = ?
    """, (id,))

    conn.commit()
    conn.close()

    return redirect("/view")

# --------------------------------

if __name__ == "__main__":
    app.run(debug=True)